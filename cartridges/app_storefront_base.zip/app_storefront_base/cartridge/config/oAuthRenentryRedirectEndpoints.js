'use strict';

module.exports = {
    1: 'Account-Show',
    2: 'Checkout-Begin'
};
